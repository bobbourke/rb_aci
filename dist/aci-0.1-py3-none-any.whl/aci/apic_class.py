import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import json
import configparser
import time
from prettytable import PrettyTable

from .error_handling_class import check_error
from .tenant_class import Tenant


class Apic:

    def __init__(self, apic):
        config = configparser.ConfigParser()
        config.read("C:/Users/BourkeR/Documents/Credentials/Credentials.txt")

        self.name = apic
        try:
            self.hostname = config.get(apic, "hostname")
            self.username = config.get(apic, "username")
            self.password = config.get(apic, "password")
        except Exception as e:
            raise Exception("Error parsing login data - {0}".format(e))

        self.base_url = "https://" + self.hostname + "/api/"
        self.token = None
        self.version = None
        self.refresh_time = None
        self.timer = None

    def login(self):
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

        url = self.base_url + "aaaLogin.json"

        payload = """{
                     "aaaUser" : {
                         "attributes" : {
                             "name" : "%s",
                             "pwd" : "%s"
                             }
                         }
                     }""" % (self.username, self.password)

        headers = {"Content-Type": "application/json"}
        request = requests.post(url, data=payload, headers=headers, verify=False)
        if request.status_code == 200:
            output = json.loads(request.text)
            output = output['imdata'][0]['aaaLogin']['attributes']
            self.version = output['version']
            self.token = output['token']
            self.refresh_time = int(output["refreshTimeoutSeconds"])
            self.timer = time.time() + (self.refresh_time - (self.refresh_time * 0.2))
        else:
            error = check_error(request)
            raise error

    def refresh_token(self):

        print("** Token Refresh **")

        headers = {'Authorization': "Bearer " + self.token,
                   'Cookie': "APIC-cookie=" + self.token}

        url = self.base_url + "aaaRefresh.json"

        request = requests.get(url, headers=headers, verify=False)

        if request.status_code == 200:
            output = json.loads(request.text)
            output = output['imdata'][0]['aaaLogin']['attributes']
            self.token = output['token']
            self.refresh_time = int(output['refreshTimeoutSeconds'])
            self.timer = time.time() + (self.refresh_time - (self.refresh_time * 0.2))
        else:
            error = check_error(request)
            raise error

    def get_request(self, url):

        if time.time() > self.timer:
            self.refresh_token()

        headers = {'Authorization': "Bearer " + self.token,
                   'Cookie': "APIC-cookie=" + self.token}

        url = self.base_url + url
        request = requests.get(url, headers=headers, verify=False)

        if request.status_code == 200:
            output = json.loads(request.text)
            output = output['imdata']
            return output
        else:
            error = check_error(request)
            raise error

    def tenants(self):

        url = "class/fvTenant.json"

        output = self.get_request(url)

        tenants = []
        for i in output:
            tenant = i['fvTenant']['attributes']
            tenant = Tenant(tenant, self)
            tenants.append(tenant)

        return tenants

    def fabric_devices(self, format_table=False):

        url = "node/class/topSystem.json?order-by=topSystem.id|asc"

        devices = self.get_request(url)

        fabric_devices = []

        for device in devices:
            dev_id = device['topSystem']['attributes']['id']
            name = device['topSystem']['attributes']['name']
            role = device['topSystem']['attributes']['role']
            pod_id = device['topSystem']['attributes']['podId']
            state = device['topSystem']['attributes']['state']

            url = "node/mo/topology/pod-{0}/node-{1}.json".format(pod_id, dev_id)
            devices_ = self.get_request(url)

            model = None
            for device_ in devices_:
                model = device_['fabricNode']['attributes']['model']

            fabric_device = {"ID": dev_id, "Name": name, "Role": role, "Model": model, "Pod ID": pod_id, "State": state}

            fabric_devices.append(fabric_device)

        if fabric_devices:
            if format_table:
                table = PrettyTable()
                table.field_names = ["ID", "Name", "Role", "Model", "Pod ID", "State"]
                table.title = "ACI Fabric Devices - {0}".format(self.name)

                for aci_device in fabric_devices:
                    table.add_row([aci_device['ID'], aci_device['Name'], aci_device['Role'], aci_device['Model'],
                                   aci_device['Pod ID'], aci_device['State']])
                return table
            else:
                return fabric_devices
        else:
            return

    def cluster_health(self, format_table=False):

        url = "node/class/infraWiNode.json"

        apics = self.get_request(url)

        apics_details = []

        for apic in apics:
            name = apic['infraWiNode']['attributes']['nodeName']
            pod_id = apic['infraWiNode']['attributes']['podId']
            health = apic['infraWiNode']['attributes']['health']
            mode = apic['infraWiNode']['attributes']['apicMode']
            op_status = apic['infraWiNode']['attributes']['operSt']
            admin_state = apic['infraWiNode']['attributes']['adminSt']
            ip_address = apic['infraWiNode']['attributes']['addr']

            apic_details = {"Name": name, "Pod ID": pod_id, "Health": health, "Mode": mode, "Op_Status": op_status,
                            "Admin_State": admin_state, "IP Address": ip_address}
            if apic_details not in apics_details:
                apics_details.append(apic_details)

        if apics_details:
            if format_table:
                table = PrettyTable()
                table.field_names = ["APIC Name", "POD ID", "Health", "Mode", "Operational State", "Admin State",
                                     "IP Address"]
                table.title = "ACI APIC Cluster Health - {0}".format(self.name)

                for apic_ in apics_details:
                    table.add_row([apic_['Name'], apic_['Pod ID'], apic_['Health'], apic_['Mode'], apic_['Op_Status'],
                                   apic_['Admin_State'], apic_['IP Address']])
                return table
            else:
                return apics_details
        else:
            return

    def license_status(self, format_table=False):

        url = "node/class/licensePermLicReserve.json"

        lic_detail = None
        lic_details = self.get_request(url)

        for lic_detail_ in lic_details:
            status = lic_detail_['licensePermLicReserve']['attributes']['authStatus']
            reg_status = lic_detail_['licensePermLicReserve']['attributes']['registerState']
            lic_detail = {"Status": status, "Registration Status": reg_status}

        if lic_detail:
            if format_table:
                table = PrettyTable()
                table.field_names = ['Status', 'Registration Status']
                table.title = "ACI Fabric License Status - {0}".format(self.name)

                table.add_row([lic_detail['Status'], lic_detail['Registration Status']])

                return table
            else:
                return lic_detail
        else:
            return
